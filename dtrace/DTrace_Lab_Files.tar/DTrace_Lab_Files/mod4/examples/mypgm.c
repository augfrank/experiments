main()
{
  int i=0;

  while ( i < 60 )
    {
    printf("Still here\n");
    sleep(1);
    ++i;
    }
}
