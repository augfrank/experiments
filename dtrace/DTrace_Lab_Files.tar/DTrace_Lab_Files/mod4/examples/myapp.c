main()
{
char *p;

  p = (char *)malloc(1000000000);
  printf("%p\n", p);
  p = (char *)malloc(1000000000);
  printf("%p\n", p);
  p = (char *)malloc(1000000000);
  printf("%p\n", p);
  p = (char *)malloc(1000000000);
  printf("%p\n", p);
  sleep(10);
}
