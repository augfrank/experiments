int x=12;

int sum(int a, int b)
{
  return(a+b);
}

int prod(int a, int b)
{
  int i;

  /* lets kill some time */
  for(i=0; i<900000; i++)
    {
    x =  sum(x*a,b);
    }
  return(a*b);
}

int div(int a, int b)
{
  return(a/b);
}

int mod(int a, int b)
{
  int i;
  int r = a % b;
  for(i=0; i<900000; i++)
    {
    x = x*a+b;
    }
  return(r);
}

main()
{
  int i;
  int f=1;
  int m, p, q;
  for(i=1; i<=100; i++)
    {
    f = sum(x,i);
    p = prod(x, f)/1000;
    q = div(x+i, i);
    m = mod(x, i*13);
    printf("f: %d\t  p: %d\t  q: %d\t  m: %d\n", f, p, q, m);
    }
}
