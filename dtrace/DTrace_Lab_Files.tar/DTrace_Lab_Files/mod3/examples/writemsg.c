main()
{
  write(1, "This is some text being", 23);
  write(1, " written to standard output", 29);
  write(1, " to prove a point\n", 18);
}
