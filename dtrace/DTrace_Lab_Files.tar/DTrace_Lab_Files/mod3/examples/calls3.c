int y = 15;
int z = 8;

int f5(int a, int b)
{
  ++z;
  return (a+b);
}

int f4(int a, int b)
{
  int r;

  r = f5(a,b)+13;
  y = z+r;
  return(r);
}

int f3(int a)
{
  int r;

  usleep(650);
  r = f4(a-3, a+3);
  z = r*y;
  return(r);
}

int f2(int a)
{
  return(f3(5*a));
}

int f1(int a, int b)
{
  int r;

  usleep(90);
  r = f2(a-b);
  y = z*r;
  return(r);
}

main()
{
  int x;

  x = f1(13,6);
  printf("x=%d y=%d z=%d\n", x, y, z);
  x = f1(17,5);
  printf("x=%d y=%d z=%d\n", x, y, z);
}
