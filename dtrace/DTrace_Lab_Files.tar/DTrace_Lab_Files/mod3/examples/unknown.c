#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdio.h>
#include <strings.h>

int nzeros;

main()
{
        DIR *dirp;
        struct dirent *dp;
        struct stat statbuf;
        int fd;
        char c;

        if ((dirp = opendir(".")) == NULL) {
                perror("couldn't open '.'");
                return;
        }
        do {
                if ((dp = readdir(dirp)) != NULL) {
            /*     printf("Opening: %s\n", dp->d_name);    */
                   fd = open(dp->d_name, O_RDONLY);
                   if (fd == -1)
                     perror("open"), perror(dp->d_name), exit(1);
                   if (stat(dp->d_name, &statbuf) == -1)
                     perror("stat"), perror(dp->d_name), exit(1);
                   if (statbuf.st_mode&S_IFREG)
                     while (read(fd, &c, 1) != 0)
                       if ( c == '\0' )
                         nzeros++;
                   (void) close(fd);
                }
        } while (dp != NULL);

        return;
}
