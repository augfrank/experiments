int f5(int a, int b)
{
  return (a+b);
}

int f4(int a, int b)
{
int r;

  r = f5(a,b)+13;
  return(r);
}

int f3(int a)
{
  int r;

  r = f4(a-3, a+3);
  return(r);
}

int f2(int a)
{
  return(f3(5*a));
}

int f1(int a, int b)
{
  int r;

  r = f2(a-b);
  return(r);
}

main()
{
  int x;

  x = f1(13,6);
  printf("%d\n", x);
}
