char msg[]="This is a message for you\n";

main()
{
  printf("Enter ^C to terminate\n");
  pause();
}
